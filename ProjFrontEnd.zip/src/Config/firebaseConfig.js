// import firebase from "firebase/compat/app";

// const firebaseApp = firebase.initializeApp({
//   apiKey: "AIzaSyAJlr3sKAYpr0gjjTaOA_a7U9q8V6MBMF8",
//   authDomain: "reactfirebasechat-6e2f2.firebaseapp.com",
//   projectId: "reactfirebasechat-6e2f2",
//   storageBucket: "reactfirebasechat-6e2f2.appspot.com",
//   messagingSenderId: "537484228639",
//   appId: "1:537484228639:web:d9b3cfb27d2247c1aa3d2a",
// });

// const db = firebaseApp.firestore();

// export { db };
