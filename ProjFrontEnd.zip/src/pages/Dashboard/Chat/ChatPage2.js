import React from "react";
import FirebaseLogin from "./FirebaseLogin";
import FirebaseRegister from "./FirebaseRegister";

const ChatPage2 = () => {
  return (
    <div>
      <FirebaseRegister />
    </div>
  );
};

export default ChatPage2;
